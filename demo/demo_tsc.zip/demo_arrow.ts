var multiply = function(x,y) {
	return x*y ;
}

var add = (x,y) => { return x+y } ;

console.log(multiply(2,4));
console.log(add(2,4)) ;