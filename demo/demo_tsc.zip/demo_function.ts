//Anonymous function
let myAdd = function (x, y) { return x+y } ;

console.log(myAdd(1,2));