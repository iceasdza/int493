let someValue: any = "this is a string";

let strLength: number = (<string>someValue).length;
console.log(strLength) ;