let age: number = 37 ;
let fullName: string = 'Sanit' ;
let sentence: string =` Hello, my name is ${ fullName }.
I am ${ age } years old.` ; 
console.log(sentence);