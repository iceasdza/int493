var num = [1,4,9,16] ;
console.log(num.map(Math.sqrt)) ;