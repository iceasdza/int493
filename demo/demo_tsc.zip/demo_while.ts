let n : number = 0 ;
while(n < 5) { 
   console.log("Entered while "+n);
   n++ ;
} 

do { 
   console.log("Entered do…while "+n) ; 
} 
while(n<5)