let fruits:string[] = ['apple','orange','peach'] ;
fruits.push('banana') ;
let len: number = fruits.length ;
for(let i=0; i<len ;i++){
	console.log(fruits[i]) ;
}
fruits.sort()
for(let i=0; i<len ;i++){
	console.log(fruits[i]) ;
}
console.log(fruits.indexOf('banana')) ;
